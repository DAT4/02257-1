// --------------------------------------------------
// ./src/DrawingTrees/DrawingTreesTest/Program.fs
// --------------------------------------------------
// 
// Author: Johan Ott 
// Date:   Tue Jun 7 13:46:07 

module Program =

    [<EntryPoint>]
    let main _ = 0
